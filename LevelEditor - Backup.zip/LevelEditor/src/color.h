#ifndef COLOR_H
#define COLOR_H

unsigned int BlendRGBA(unsigned int sourceColor, unsigned int destColor, double alpha);

#endif